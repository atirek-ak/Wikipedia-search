Folders:
index/ - stores index before merging
Inverted Index/ - stores index after merging
title/ - Stores title of document with associated document ID

Files:
total.txt - stores total number of documents in wiki-dump